from AbstractCircuit import AbstractCircuit
from QuantumGate import *
from typing import List


def loopup(table: List,
           length: int) -> AbstractCircuit:
    pass